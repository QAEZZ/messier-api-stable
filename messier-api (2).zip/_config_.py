import os
import random
import time

print("_config_")