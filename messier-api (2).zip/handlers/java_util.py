"""
from aiohttp import web
import json


class java_util(web.Application):
	def __init__(self, app):
		self.app = app

	# /convertHashmapJson
	async def convertHashmapJson(self, request):
    # to convert json to hashmap:
    #  - /convertHashapJson?json={"your":"json"}

    # to convert hashmap to json
    #  - /convertHashapJson?hashmap={your=hashmap}

		if "hashmap" in request.query:
			rs_json = {}
			hashmap = request.query["hashmap"].replace("{", "").replace("}", "").replace(", ", ",")
			for pair in hashmap.split(","):
				key, value = pair.split("=")
				rs_json[key] = value
			return web.json_response(rs_json)
      
		elif "json" in request.query:
			rs_json = json.loads(request.query["json"])
			hashmap = "{"
			for key in rs_json:
				hashmap += f"{key}={rs_json[key]},"
			hashmap = hashmap[:-1] + "}"
			return web.Response(text=hashmap)
		else:
			return web.FileResponse("./static/html/docs/index.html")


  async def something(self, request):
    print("something")
    return {"name": "hello"}


def setup(app):
	  return java_util(app), {"convertHashmapJson": "/convertHashmapJson", "something": "/something"}
"""

from aiohttp import web
import json


class java_util(web.Application):
    def __init__(self, app):
        self.app = app

    # /convertHashmapJson
    async def convertHashmapJson(self, request):
        if "hashmap" in request.query:
            rs_json = {}
            hashmap = request.query["hashmap"].replace("{", "").replace(
                "}", "").replace(", ", ",")
            for pair in hashmap.split(","):
                key, value = pair.split("=")
                rs_json[key] = value

            return web.json_response(rs_json)

        elif "json" in request.query:
            rs_json = json.loads(request.query["json"])
            hashmap = "{"
            for key in rs_json:
                hashmap += f"{key}={rs_json[key]}"
            print(rs_json)
            if hashmap[-1] == ",":
              hashmap = hashmap[:-1]
            hashmap = hashmap + "}"
            return web.Response(text=hashmap)
# shit school started, ill be in 40 min
        else:
            return web.FileResponse("./static/html/docs/index.html")

    async def something(self, request):
      return {"name": "test"}


def setup(app):
    return java_util(app), {"convertHashmapJson": "/convertHashmapJson", "something": "/something"}

# /something returns 500 but there is nothing in log.log
# /convertHashmapJson returns 404 (even when passing in ?json={json here})

# Ill probably try to use a try/except and print except as e into the console
